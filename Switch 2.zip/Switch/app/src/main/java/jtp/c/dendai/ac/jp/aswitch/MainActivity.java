package jtp.c.dendai.ac.jp.aswitch;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {

    //private GameActivity gameActivity;
    private TitleActivity titleActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
}
