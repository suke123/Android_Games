package jtp.c.dendai.ac.jp.switch_test;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

/**
 * Created by taka on 2017/10/25.
 */

public class GameView extends SurfaceView implements SurfaceHolder.Callback {

    private static final Paint PAINT = new Paint();
    //private Map map;

    private static final long FPS = 100;

    //private Bitmap boy,girl;
    private Map map;
    private Bitmap backGroundImg;
    Activity activity;
    private Boy boy;
    private Girl girl;

    private int bx = 1500, by = 500, gx = 500, gy = 500;

    private class DrawThread extends Thread{
        boolean isFinished;

        @Override
        public void run(){
            SurfaceHolder holder = getHolder();

            while (!isFinished){
                Canvas canvas = holder.lockCanvas();
                if (canvas != null){
                    drawGame(canvas);
                    holder.unlockCanvasAndPost(canvas);
                }

                try {
                    sleep(1000/FPS);
                }catch (InterruptedException e){

                }
            }
        }
    }

    private DrawThread drawThread;

    public void startDrawThread(){
        stopDrawThread();

        drawThread = new DrawThread();
        drawThread.start();
    }

    private boolean stopDrawThread() {
        if(drawThread == null){
            return false;
        }
        drawThread.isFinished = true;
        drawThread = null;
        return true;
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder){
        startDrawThread();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int widt, int height){
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder){
        stopDrawThread();
    }

    public GameView(Context context, Activity a){
        super(context);
        getHolder().addCallback(this);
        this.activity = a;

        if(map == null){
            map = new Map(context);
        }
    }

    public void drawGame(Canvas canvas){
        //int width = canvas.getWidth();
        //int height = canvas.getHeight();
        //backGroundImg = BitmapFactory.decodeResource(getResources(), R.drawable.game_back);
        //    canvas.drawBitmap(backGroundImg, 0, 0, PAINT);

        if(boy == null){
            Bitmap boyBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.boy1);
            boy = new Boy(boyBitmap, bx, by);
        }
        if (girl == null){
            Bitmap girlBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.girl1);
            girl = new Girl(girlBitmap, gx, gy);
        }

        //boy.move();
        //girl.move();
        map.draw(canvas, 0, 0);
        boy.draw(canvas);
        girl.draw(canvas);

        //invalidate();
    }

}
