package jtp.c.dendai.ac.jp.switch_test;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class GameActivity extends AppCompatActivity {

    private GameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        gameView = new GameView(this, this);

        setContentView(gameView);
        //setContentView(R.layout.activity_game);
    }
}
