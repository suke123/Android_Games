package jtp.c.dendai.ac.jp.switch_test;

import android.graphics.Bitmap;

public interface Idealist {
    public Bitmap getBit(int i);
   /* void set(int i, int j);
    int getScore();
    void draw(Canvas canvas);
    void stop();
    void move(int width, int height);
    void step(double t, int width, int height);
    Rect getRect();
    boolean intersect(int m);
    int houkou(float w, float x, int y, int z);
    boolean isAlive();
    void dead();
    double getInterval();
    void setRect();
    int rand(int x, boolean u);
    */

}
