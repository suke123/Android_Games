package jtp.c.dendai.ac.jp.switch3;

import android.content.Context;
import android.view.SurfaceView;

/**
 * Created by DE on 2017/10/23.
 */

public class View extends SurfaceView {

    public View(Context context) {
        super(context);
    }
}
