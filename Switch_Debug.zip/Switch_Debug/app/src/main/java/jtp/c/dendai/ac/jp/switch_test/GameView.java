package jtp.c.dendai.ac.jp.switch_test;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

/**
 * Created by taka on 2017/10/25.
 */

public class GameView extends SurfaceView implements SurfaceHolder.Callback {

    private static final Paint PAINT = new Paint();
    //private Map map;

    private static final long FPS = 100;
    private int cycle;
    //private int clock;
    protected final int width;
    protected final int height;
    protected double period;
    //private Bitmap boy,girl;
    private Map map;
    //private Bitmap backGroundImg;
    private Bitmap[] Bits;
    private static final int[] ids = {R.drawable.boy1,R.drawable.boy2,R.drawable.boy3, R.drawable.boy4,
            R.drawable.girl1,R.drawable.girl2,R.drawable.girl3, R.drawable.girl4};
    //  private static final int[] ids2 = {R.drawable.girl1,R.drawable.girl2,R.drawable.girl3, R.drawable.girl4};

    Activity activity;
    private Boy boy;
    private Girl girl;

    private int bx = 1500, by = 500, gx = 500, gy = 500;

    private class DrawThread extends Thread{
        boolean isFinished;

        @Override
        public void run(){

            SurfaceHolder holder = getHolder();

            while (!isFinished){

                Canvas canvas = holder.lockCanvas();
                if (canvas != null){
                    //boy.update();
                    //girl.update();

                    drawGame(canvas);
                    holder.unlockCanvasAndPost(canvas);

                }
                try {
                    sleep(1000/FPS);
                }catch (InterruptedException e){

                }
            }
        }
    }

    private class MoveThread extends Thread{
        boolean isFinished;

        @Override
        public void run(){

            SurfaceHolder holder = getHolder();

            while (!isFinished){

                Canvas canvas = holder.lockCanvas();
                if (canvas != null){
                    boy.update();
                    girl.update();

                    drawGame(canvas);
                    holder.unlockCanvasAndPost(canvas);

                }
                try {
                    sleep(1000/FPS);
                }catch (InterruptedException e){

                }
            }
        }
    }




    private DrawThread drawThread;

    public void startDrawThread(){
        stopDrawThread();

        drawThread = new DrawThread();
        drawThread.start();
    }

    private boolean stopDrawThread() {
        if(drawThread == null){
            return false;
        }
        drawThread.isFinished = true;
        drawThread = null;
        return true;
    }

    private MoveThread moveThread;

    public void startMoveThread(){
        stopMoveThread();

        moveThread = new MoveThread();
        moveThread.start();
    }

    private boolean stopMoveThread() {
        if(drawThread == null){
            return false;
        }
        drawThread.isFinished = true;
        drawThread = null;
        return true;
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder){
        startDrawThread();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int widt, int height){
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder){
        stopDrawThread();
    }

    public GameView(Context context, Activity a){
        super(context);
        getHolder().addCallback(this);
        this.activity = a;

        if(map == null){
            map = new Map(context);
        }

        cycle = ids.length;
        Bits = new Bitmap[cycle];
        for (int i = 0; i < cycle; i++) {
            Bits[i] = BitmapFactory.decodeResource(getResources(), ids[i]);
        }
        width = Bits[0].getWidth();
        height = Bits[0].getHeight();
        //clock = 0;
        period = 0;

    }

    public void drawGame(Canvas canvas){
        //int width = canvas.getWidth();
        //int height = canvas.getHeight();
        //backGroundImg = BitmapFactory.decodeResource(getResources(), R.drawable.game_back);
        //    canvas.drawBitmap(backGroundImg, 0, 0, PAINT);

        if(boy == null){
        //    Bitmap boyBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.boy1);
            boy = new Boy(100.0,20.0,Bits[0], bx, by,map);
        }
        if (girl == null){
     //       Bitmap girlBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.girl1);
            girl = new Girl(200.0,20.0,Bits[4], gx, gy,map);
        }

        //boy.move();
        //girl.move();
        map.draw(canvas, 0, 0);
        boy.draw(canvas);
        girl.draw(canvas);

        //invalidate();
    }



    public void paintComponent(Canvas canvas) {
     //   Paint pei = new Paint();
     //   Paint peint = new Paint();
        //  super.paintComponent(g);

        // 背景を黒で塗りつぶす
       // PAINT.setColor(Color.BLACK);
        //   pei.fillRect(0, 0, getWidth(), getHeight());

        // X方向のオフセットを計算
        int offsetX = MainPanel.WIDTH / 2 - (int) boy.getX();
        int offsetX2 = MainPanel.WIDTH / 2 - (int) girl.getX();
        // マップの端ではスクロールしないようにする
        offsetX = Math.min(offsetX, 0);
        offsetX = Math.max(offsetX, MainPanel.WIDTH - map.getWidth2());
        offsetX2 = Math.min(offsetX2, 0);
        offsetX2 = Math.max(offsetX2, MainPanel.WIDTH - map.getWidth2());


        // Y方向のオフセットを計算
        int offsetY = MainPanel.HEIGHT / 2 - (int) boy.getY();
        int offsetY2 = MainPanel.HEIGHT / 2 - (int) girl.getY();
        // マップの端ではスクロールしないようにする
        offsetY = Math.min(offsetY, 0);
        offsetY = Math.max(offsetY, MainPanel.HEIGHT - map.getHeight2());
        offsetY2 = Math.min(offsetY2, 0);
        offsetY2 = Math.max(offsetY2, MainPanel.HEIGHT - map.getHeight2());

        // マップを描画
        map.draw(canvas, offsetX, offsetY);

        // プレイヤーを描画
        boy.draw(canvas, offsetX, offsetY);

        girl.draw(canvas, offsetX, offsetY);
    }


}
