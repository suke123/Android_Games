package jtp.c.dendai.ac.jp.switch_test;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;

public class GameActivity extends AppCompatActivity implements View.OnClickListener{//, View.OnLongClickListener {

    private GameView gameView;
    private ImageButton left,right,up,change;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        View bgView = getLayoutInflater().inflate(R.layout.game, null);
        addContentView(bgView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));

        gameView = new GameView(this, this);

        setContentView(gameView);

        View view = getLayoutInflater().inflate(R.layout.activity_game, null);
        addContentView(view, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));
        //setContentView(R.layout.activity_game);

        setButtonId();
        setButtonOnClickListener();
        //setButtonOnLongClickListener();

    }

/*
    private void setButtonOnLongClickListener() {
        left.setOnLongClickListener(this);
        right.setOnLongClickListener(this);
    }
*/

    private void setButtonOnClickListener() {
        left.setOnClickListener(this);
        right.setOnClickListener(this);
        up.setOnClickListener(this);
        change.setOnClickListener(this);
    }

    private void setButtonId() {
        left = (ImageButton)findViewById(R.id.array_left_Button);
        right = (ImageButton)findViewById(R.id.array_right_Button);
        up = (ImageButton)findViewById(R.id.array_up_Button);
        change = (ImageButton)findViewById(R.id.change_Button);
    }

    @Override
    public void onClick(View v){
        switch (v.getId()){
            case R.id.array_left_Button:

                break;
            case R.id.array_right_Button:

                break;
            case R.id.change_Button:

                break;

            case R.id.array_up_Button:

                break;
        }
    }

/*
    @Override
    public boolean onLongClick(View v){
        switch (v.getId()){
            case R.id.array_left_Button:

                break;
            case R.id.array_right_Button:

                break;
        }
        return true;
    }
*/

}
