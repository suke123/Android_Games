/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jtp.c.dendai.ac.jp.switch_test;

import android.graphics.Canvas;

/**
 *
 * @author kie
 */
public class Score {
    
    private int irekae=0;
    
    public int getIre(){
    return irekae;
    }
    
    public void setIre(int a){
    irekae = a;
    
    }
    
        public void draw(Canvas canvas, int i) {
            String s= String.valueOf(i);

    }
    
    
}
