package jtp.c.dendai.ac.jp.switch_test;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

/**
 * Created by taka on 2017/10/25.
 */

public class GameView extends SurfaceView implements SurfaceHolder.Callback {

    private static final Paint PAINT = new Paint();
    //private Map map;
    public static final int WIDTH = 640;
    public static final int HEIGHT = 480;
    private static final long FPS = 100;
    private int cycle;
    private int clock;
    protected final int width;
    protected final int height;
    protected double period;
    //private Bitmap boy,girl;
    private Map map;
    private Bitmap backGroundImg;
    private Bitmap[] Bits;
    private int offsetX=0,offsetY=0,offsetX2=0,offsetY2=0;
    public static  Point VIEW_SIZE = new Point(0,0);


    private static final int[] ids = {R.drawable.boy1,R.drawable.boy2,R.drawable.boy3, R.drawable.boy4,
            R.drawable.girl1,R.drawable.girl2,R.drawable.girl3, R.drawable.girl4};
    //  private static final int[] ids2 = {R.drawable.girl1,R.drawable.girl2,R.drawable.girl3, R.drawable.girl4};

    Activity activity;
    private Boy boy;
    private Girl girl;

    private int bx = 1500, by = 500, gx = 500, gy = 500;

    //true:boy, false:girl を操作可能
    public boolean isBoy = false;

    private class DrawThread extends Thread{
        boolean isFinished;

        @Override
        public void run(){

            SurfaceHolder holder = getHolder();

            while (!isFinished){

                Canvas canvas = holder.lockCanvas();
                if (canvas != null){
                    //boy.update();
                    //girl.update();
                    Move2();
                    paintComponent(canvas);
                    drawDebug(canvas);
                    //drawGame(canvas);
                    holder.unlockCanvasAndPost(canvas);

                }
                try {
                    sleep(1000/FPS);
                }catch (InterruptedException e){

                }
            }
        }
    }

    private class MoveThread extends Thread{
        boolean isFinished;

        @Override
        public void run(){

            SurfaceHolder holder = getHolder();

            while (!isFinished){

                Canvas canvas = holder.lockCanvas();
                if (canvas != null){
                    boygirl(100.0,20.0,200.0,20.0);
                    boy.update();
                    girl.update();
                    // paintComponent(canvas);
                    //　drawGame(canvas);
                    holder.unlockCanvasAndPost(canvas);

                }
                try {
                    sleep(1000/FPS);
                }catch (InterruptedException e){

                }
            }
        }
    }




    private DrawThread drawThread;

    public void startDrawThread(){
        stopDrawThread();

        drawThread = new DrawThread();
        drawThread.start();
    }

    private boolean stopDrawThread() {
        if(drawThread == null){
            return false;
        }
        drawThread.isFinished = true;
        drawThread = null;
        return true;
    }

    private MoveThread moveThread;

    public void startMoveThread(){
        stopMoveThread();

        moveThread = new MoveThread();
        moveThread.start();
    }

    private boolean stopMoveThread() {
        if(drawThread == null){
            return false;
        }
        drawThread.isFinished = true;
        drawThread = null;
        return true;
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder){
        startMoveThread();
        startDrawThread();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height){
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder){
        stopMoveThread();
        stopDrawThread();
    }


    //こんすとらくた
    public GameView(Context context, Activity a, String filename){
        super(context);
        getHolder().addCallback(this);
        this.activity = a;
        VIEW_SIZE = getDisplaySize(activity);
        VIEW_SIZE = new Point(1776,999);

        if(map == null){
            map = new Map(context);
        }

        cycle = ids.length;
        Bits = new Bitmap[cycle];
        for (int i = 0; i < cycle; i++) {
            Bits[i] = BitmapFactory.decodeResource(getResources(), ids[i]);
        }
        width = Bits[0].getWidth();
        height = Bits[0].getHeight();
        clock = 0;
        period = 0;

    }

    public static Point getDisplaySize(Activity activ){
        Display display = activ.getWindowManager().getDefaultDisplay();
        Point point = new Point();
        display.getSize(point);
        return point;
    }

    public void drawGame(Canvas canvas){
        //int width = canvas.getWidth();
        //int height = canvas.getHeight();
        //backGroundImg = BitmapFactory.decodeResource(getResources(), R.drawable.game_back);
        //    canvas.drawBitmap(backGroundImg, 0, 0, PAINT);

        if(boy == null){
        //    Bitmap boyBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.boy1);
            boy = new Boy(100.0,20.0,Bits[0], bx, by,map);
        }
        if (girl == null){
     //       Bitmap girlBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.girl1);
            girl = new Girl(200.0,20.0,Bits[4], gx, gy,map);
        }

        //boy.move();
        //girl.move();
        map.draw(canvas, 0, 0);
        boy.draw(canvas);
        girl.draw(canvas);

        //invalidate();
    }


    public void boygirl(Double x1,Double y1,Double x2,Double y2){

        if(boy == null){
            int aa = VIEW_SIZE.x<100 ? 100 :VIEW_SIZE.x;
            //    Bitmap boyBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.boy1);
            boy = new Boy(x1,y1,Bits[0], bx, by,map);
        }
        if (girl == null){
            //       Bitmap girlBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.girl1);
            girl = new Girl(x2,y2,Bits[4], gx, gy,map);
        }


    }

    public Point GetSizeView(){
        return VIEW_SIZE;
    }


    public  void drawDebug(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(Color.CYAN);
        paint.setTextSize(40);

        canvas.drawText("X:"+VIEW_SIZE.x+" Y:"+VIEW_SIZE.y, 600, 100, paint);
    }



    public void paintComponent(Canvas canvas) {

        if(boy == null){
            //    Bitmap boyBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.boy1);
            boy = new Boy(100.0,20.0,Bits[0], bx, by,map);
        }
        if (girl == null){
            //       Bitmap girlBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.girl1);
            girl = new Girl(400.0,20.0,Bits[4], gx, gy,map);
        }
        //   Paint pei = new Paint();
        //   Paint peint = new Paint();
        //  super.paintComponent(g);

        // 背景を黒で塗りつぶす
        PAINT.setColor(Color.WHITE);
        Rect rect = new Rect(0, 0, VIEW_SIZE.x,VIEW_SIZE.y);
        canvas.drawRect(rect, PAINT);
/*
        // X方向のオフセットを計算
        int offsetX = MainPanel.WIDTH / 2 - (int) boy.getX();
        int offsetX2 = MainPanel.WIDTH / 2 - (int) girl.getX();
        // マップの端ではスクロールしないようにする
        offsetX = Math.min(offsetX, 0);
        offsetX = Math.max(offsetX, MainPanel.WIDTH - map.getWidth2());
        offsetX2 = Math.min(offsetX2, 0);
        offsetX2 = Math.max(offsetX2, MainPanel.WIDTH - map.getWidth2());


        // Y方向のオフセットを計算
        int offsetY = MainPanel.HEIGHT / 2 - (int) boy.getY();
        int offsetY2 = MainPanel.HEIGHT / 2 - (int) girl.getY();
        // マップの端ではスクロールしないようにする
        offsetY = Math.min(offsetY, 0);
        offsetY = Math.max(offsetY, MainPanel.HEIGHT - map.getHeight2());
        offsetY2 = Math.min(offsetY2, 0);
        offsetY2 = Math.max(offsetY2, MainPanel.HEIGHT - map.getHeight2());
*/
        // マップを描画
        map.draw(canvas, offsetX, offsetY);

        // プレイヤーを描画
        boy.draw(canvas, offsetX, offsetY);

        girl.draw(canvas, offsetX2, offsetY2);
    }


    public void Move2(){
        if(boy == null){
            //    Bitmap boyBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.boy1);
            boy = new Boy(100.0,20.0,Bits[0], bx, by,map);
        }
        if (girl == null){
            //       Bitmap girlBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.girl1);
            girl = new Girl(400.0,20.0,Bits[4], gx, gy,map);
        }
        // X方向のオフセットを計算
        offsetX = VIEW_SIZE.x / 2 - (int) boy.getX();
        offsetX2 = VIEW_SIZE.x / 2 - (int) girl.getX();
        // マップの端ではスクロールしないようにする
        offsetX = Math.min(offsetX, 0);
        offsetX = Math.max(offsetX, VIEW_SIZE.x - map.getWidth2());
        offsetX2 = Math.min(offsetX2, 0);
        offsetX2 = Math.max(offsetX2, VIEW_SIZE.x - map.getWidth2());


        // Y方向のオフセットを計算
        offsetY = VIEW_SIZE.y / 2 - (int) boy.getY();
        offsetY2 = VIEW_SIZE.y / 2 - (int) girl.getY();
        // マップの端ではスクロールしないようにする
        offsetY = Math.min(offsetY, 0);
        offsetY = Math.max(offsetY, VIEW_SIZE.y - map.getHeight2());
        offsetY2 = Math.min(offsetY2, 0);
        offsetY2 = Math.max(offsetY2, VIEW_SIZE.y - map.getHeight2());
    }

    //今どっちが使用できるのか
    public boolean getIsBoy(){
        return isBoy;
    }

    public void setIsBoy(int i){
        if(i == 1){ //男操作可
            isBoy = true;
        }
        else { //女操作可
            isBoy = false;
        }
    }

    public void boyMoveRight(){
        boy.accelerateRight();
    }

    public void boyMoveLeft(){
        boy.accelerateLeft();
    }

    public void boyJump(){
        boy.jump();
    }

    public void girlMoveRight(){
        girl.accelerateRight();
    }

    public void girlMoveLeft(){
        girl.accelerateLeft();
    }

    public void girlJump(){
        girl.jump();
    }


}
